# Instruction Following Eval

A benchmark dataset for evaluating whether LLM-generated responses comply with explicit constraints specified in their instructions.

## Overview

Large language models are increasingly evaluated not just on *what* they say, but on whether they follow *how* they were told to say it. This dataset targets **instruction-following compliance** — the ability to detect whether a response satisfies format, length, style, structural, and content constraints.

Each row pairs an instruction (containing one or more verifiable constraints) with an LLM response and ground-truth labels for whether each constraint was met.

## Task

**Primary task:** Given an `instruction` and a `response`, predict `all_constraints_satisfied` (binary: 1 = all met, 0 = at least one violated).

**Secondary task:** Given the `constraints` JSON, predict per-constraint `satisfied` labels.

## Schema

| Column | Type | Description |
|--------|------|-------------|
| `id` | int | Unique row identifier |
| `instruction` | string | Prompt with one or more explicit constraints |
| `constraint_type` | string | Primary constraint category |
| `constraints` | JSON string | Array of `{type, description, satisfied}` objects |
| `num_constraints` | int | Number of individual constraints (1–5) |
| `response` | string | LLM-generated response to evaluate |
| `all_constraints_satisfied` | int | 1 if all constraints met, 0 otherwise |
| `difficulty` | string | `easy` / `medium` / `hard` |

## Constraint Types

| Type | Count | Description |
|------|-------|-------------|
| `length` | 14 | Word count, sentence count, character limits |
| `format` | 7 | Markdown tables, bullet points, JSON, numbered lists |
| `content_inclusion` | 9 | Required keywords, phrases, or concepts |
| `content_exclusion` | 5 | Forbidden words or patterns |
| `style` | 9 | Tone, voice, audience level, formality |
| `structural` | 6 | First/last word, sentence ordering, section labels |

## Statistics

- **Total rows:** 50
- **Label distribution:** 62% satisfied / 38% violated
- **Difficulty split:** 15 easy / 21 medium / 14 hard
- **Constraints per row:** 1–5 (mean ~1.9)

## Example

```
Instruction: "Explain what a neural network is in exactly 3 sentences."

Constraints: [{"type": "length", "description": "Response must contain exactly 3 sentences", "satisfied": true}]

Response: "A neural network is a computational model inspired by the human brain. 
It consists of layers of interconnected nodes that process information through 
weighted connections. These networks learn patterns from data by adjusting their 
weights during training."

Label: 1 (all constraints satisfied)
```

## Usage

```python
import pandas as pd
import json

df = pd.read_csv("data.csv")

# Parse per-constraint labels
df["parsed_constraints"] = df["constraints"].apply(json.loads)

# Filter by constraint type
format_rows = df[df["constraint_type"] == "format"]

# Get violation examples
violations = df[df["all_constraints_satisfied"] == 0]
```

## Generation Methodology

This dataset was synthetically constructed with the following principles:

1. **Diverse constraint types** — covering 6 distinct categories to prevent narrow evaluation
2. **Realistic violations** — failures are subtle and plausible (e.g., using a forbidden word once in a long response, exceeding word count by a small margin)
3. **Balanced difficulty** — easy constraints (single, clear-cut) through hard (multi-constraint with style + structural requirements)
4. **No AI-generated labels** — all constraint satisfaction labels were manually verified against the response text

## Intended Use

- Benchmarking LLM instruction-following capabilities
- Training constraint-satisfaction classifiers
- Evaluating automated grading/rubric systems
- Research in LLM alignment and controllability

## Limitations

- Dataset size (50 rows) is suitable as a seed benchmark; scale up for production training
- English-only
- Constraints are explicit (stated in instruction) — does not cover implicit expectations
- Responses are synthetic and may not reflect all real-world LLM failure modes

## License

Apache 2.0
