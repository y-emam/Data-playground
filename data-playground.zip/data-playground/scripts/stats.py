"""Print summary statistics for a dataset."""

import argparse
import json
import pandas as pd


def stats(data_path: str):
    df = pd.read_csv(data_path)

    print(f"{'='*50}")
    print(f"  Dataset: {data_path}")
    print(f"{'='*50}\n")

    print(f"Rows: {len(df)}")
    print(f"Columns: {len(df.columns)}\n")

    # Label distribution
    if "all_constraints_satisfied" in df.columns:
        dist = df["all_constraints_satisfied"].value_counts()
        total = len(df)
        print("Label Distribution:")
        print(f"  Satisfied (1): {dist.get(1, 0)} ({dist.get(1, 0)/total*100:.0f}%)")
        print(f"  Violated  (0): {dist.get(0, 0)} ({dist.get(0, 0)/total*100:.0f}%)")
        print()

    # Constraint types
    if "constraint_type" in df.columns:
        print("Constraint Types:")
        for ct, count in df["constraint_type"].value_counts().items():
            print(f"  {ct}: {count}")
        print()

    # Difficulty
    if "difficulty" in df.columns:
        print("Difficulty:")
        for d in ["easy", "medium", "hard"]:
            count = len(df[df["difficulty"] == d])
            print(f"  {d}: {count}")
        print()

    # Constraints per row
    if "num_constraints" in df.columns:
        print("Constraints per Row:")
        print(f"  min: {df['num_constraints'].min()}")
        print(f"  max: {df['num_constraints'].max()}")
        print(f"  mean: {df['num_constraints'].mean():.1f}")
        print()

    # Text length stats
    if "instruction" in df.columns:
        lengths = df["instruction"].str.len()
        print("Instruction Length (chars):")
        print(f"  min: {lengths.min()}, max: {lengths.max()}, mean: {lengths.mean():.0f}")

    if "response" in df.columns:
        lengths = df["response"].str.len()
        print(f"Response Length (chars):")
        print(f"  min: {lengths.min()}, max: {lengths.max()}, mean: {lengths.mean():.0f}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Dataset statistics")
    parser.add_argument("data", help="Path to CSV file")
    args = parser.parse_args()
    stats(args.data)
