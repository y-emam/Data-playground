"""Validate a dataset CSV against its schema.json definition."""

import argparse
import json
import sys
import pandas as pd


def validate(data_path: str, schema_path: str) -> list[str]:
    errors = []

    with open(schema_path) as f:
        schema = json.load(f)

    df = pd.read_csv(data_path)

    # Check all columns exist
    expected_cols = [c["name"] for c in schema["columns"]]
    for col in expected_cols:
        if col not in df.columns:
            errors.append(f"Missing column: {col}")

    extra_cols = set(df.columns) - set(expected_cols)
    if extra_cols:
        errors.append(f"Unexpected columns: {extra_cols}")

    if errors:
        return errors

    for col_schema in schema["columns"]:
        name = col_schema["name"]
        col = df[name]

        # Nullable check
        if not col_schema.get("nullable", True) and col.isnull().any():
            null_count = col.isnull().sum()
            errors.append(f"Column '{name}' has {null_count} null values but is not nullable")

        # Enum check
        if "enum" in col_schema:
            valid = set(col_schema["enum"])
            invalid = set(col.dropna().unique()) - valid
            if invalid:
                errors.append(f"Column '{name}' has invalid values: {invalid} (expected: {valid})")

        # JSON parse check
        if col_schema.get("type") == "json_string":
            for idx, val in col.items():
                try:
                    json.loads(val)
                except (json.JSONDecodeError, TypeError):
                    errors.append(f"Column '{name}' row {idx}: invalid JSON")

        # Range check
        if "min" in col_schema:
            below = col[col < col_schema["min"]]
            if len(below) > 0:
                errors.append(f"Column '{name}' has {len(below)} values below min ({col_schema['min']})")

    # Primary key uniqueness
    pk = schema.get("primary_key")
    if pk and df[pk].duplicated().any():
        errors.append(f"Primary key '{pk}' has duplicate values")

    return errors


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Validate dataset against schema")
    parser.add_argument("data", help="Path to CSV file")
    parser.add_argument("schema", help="Path to schema.json")
    args = parser.parse_args()

    errors = validate(args.data, args.schema)

    if errors:
        print(f"❌ Validation failed with {len(errors)} error(s):\n")
        for e in errors:
            print(f"  • {e}")
        sys.exit(1)
    else:
        print("✅ Dataset is valid")
        sys.exit(0)
